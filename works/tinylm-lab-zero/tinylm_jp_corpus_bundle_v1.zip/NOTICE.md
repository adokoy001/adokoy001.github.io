# NOTICE

## Original component

`tinylm_jp_original_100k.txt`、`evaluation_prompts.txt`、生成・検証スクリプトおよび付属文書は、この成果物のために作成したものです。既存コーパスの文章をオリジナル部分へコピーしていません。権利が成立する範囲で、CC0 1.0により提供します。保証はありません。

## Public component

- Source: **llm-jp/oasst2-33k-ja**
- Source URL: https://huggingface.co/datasets/llm-jp/oasst2-33k-ja
- Upstream project: OpenAssistant OASST2
- License declared by the dataset card: Apache License 2.0
- Source file: `oasst2-33k-ja.jsonl`
- Source SHA-256: `71f82d3d6bb167a03b0a09794097ba020bfcffda531a404508d26ee80a62497d`
- Selected subset: 28 independent two-turn conversations

Changes made to the public component:

1. restricted selection to an exact manually reviewed allowlist;
2. removed all non-selected conversations;
3. normalized Unicode to NFKC;
4. collapsed repeated horizontal whitespace and flattened internal newlines;
5. renamed roles to `[利用者]` and `[助手]`;
6. placed role changes on one line for TinyLM Lab Zero compatibility;
7. interleaved the selected records with the original component in `tinylm_jp_combined.txt`.

The selected source line numbers and pair hashes are recorded in `oasst2_selection_manifest.jsonl`. No additional upstream NOTICE text was supplied in the source repository inspected for this build. The upstream authors and contributors do not endorse this derivative subset.

The public subset may contain translation artifacts or factual errors despite manual selection. It is supplied without warranty.
