#!/usr/bin/env python3
"""Validate the generated TinyLM Japanese dialogue corpus bundle."""

from __future__ import annotations

import argparse
import hashlib
import json
import re
from collections import defaultdict
from pathlib import Path


ROLE_RE = re.compile(r"\[(利用者|助手)\](.*?)(?= \[(?:利用者|助手)\]|$)")


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as fh:
        for chunk in iter(lambda: fh.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def parse_dialogues(text: str) -> tuple[list[list[tuple[str, str]]], list[str]]:
    conversations: list[list[tuple[str, str]]] = []
    errors: list[str] = []
    raw_blocks = [block for block in text.strip().split("\n\n") if block]
    for index, block in enumerate(raw_blocks, 1):
        turns = ROLE_RE.findall(block)
        rebuilt = " ".join(f"[{role}]{content}" for role, content in turns)
        if rebuilt != block:
            errors.append(f"dialogue {index}: unparsed text or bad separator")
        if not turns or len(turns) % 2:
            errors.append(f"dialogue {index}: turn count is not a positive even number")
        for turn_index, (role, content) in enumerate(turns):
            expected = "利用者" if turn_index % 2 == 0 else "助手"
            if role != expected:
                errors.append(f"dialogue {index}: expected {expected} at turn {turn_index + 1}")
            if not content.strip():
                errors.append(f"dialogue {index}: empty turn {turn_index + 1}")
        conversations.append(turns)
    if len(raw_blocks) != len(set(raw_blocks)):
        errors.append("duplicate dialogue blocks found")
    return conversations, errors


def prefix_metrics(conversations: list[list[tuple[str, str]]], context: int = 64) -> dict:
    full_targets: dict[str, set[str]] = defaultdict(set)
    tail_targets: dict[str, set[str]] = defaultdict(set)
    first_prefix_lengths: list[int] = []
    for turns in conversations:
        for index, (role, answer) in enumerate(turns):
            if role != "助手":
                continue
            prefix = " ".join(f"[{r}]{text}" for r, text in turns[:index]) + " [助手]"
            full_targets[prefix].add(answer)
            tail_targets[prefix[-context:]].add(answer)
            if index == 1:
                first_prefix_lengths.append(len(prefix))
    return {
        "context_characters": context,
        "full_prefix_conflicts": sum(len(values) > 1 for values in full_targets.values()),
        "tail_prefix_conflicts": sum(len(values) > 1 for values in tail_targets.values()),
        "max_first_assistant_prefix": max(first_prefix_lengths, default=0),
        "first_assistant_prefixes_over_context": sum(
            length > context for length in first_prefix_lengths
        ),
    }


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--directory", type=Path, default=Path(__file__).resolve().parent)
    ap.add_argument("--report", type=Path)
    args = ap.parse_args()
    root = args.directory
    report_path = args.report or root / "validation_report.json"

    original_path = root / "tinylm_jp_original_100k.txt"
    public_path = root / "tinylm_jp_oasst2_open.txt"
    combined_path = root / "tinylm_jp_combined.txt"
    evaluation_path = root / "evaluation_prompts.txt"
    manifest_path = root / "oasst2_selection_manifest.jsonl"

    failures: list[str] = []
    original = original_path.read_text(encoding="utf-8")
    public = public_path.read_text(encoding="utf-8")
    combined = combined_path.read_text(encoding="utf-8")
    evaluation = evaluation_path.read_text(encoding="utf-8")

    original_dialogues, original_errors = parse_dialogues(original)
    public_dialogues, public_errors = parse_dialogues(public)
    combined_dialogues, combined_errors = parse_dialogues(combined)
    failures.extend(f"original: {error}" for error in original_errors)
    failures.extend(f"public: {error}" for error in public_errors)
    failures.extend(f"combined: {error}" for error in combined_errors)

    if not 100_000 <= len(original) <= 101_000:
        failures.append(f"original size outside 100000..101000: {len(original)}")
    if len(combined) != len(original) + len(public):
        failures.append("combined character count is not original + public")

    prefixes = prefix_metrics(original_dialogues, 64)
    if prefixes["full_prefix_conflicts"]:
        failures.append("original has identical full prefixes with different targets")
    if prefixes["tail_prefix_conflicts"]:
        failures.append("original has identical 64-character prefixes with different targets")
    if prefixes["first_assistant_prefixes_over_context"]:
        failures.append("an initial user prompt plus assistant marker exceeds ctx=64")

    public_prefixes = prefix_metrics(public_dialogues, 64)
    public_max_answer = max(
        (len(text) for turns in public_dialogues for role, text in turns if role == "助手"),
        default=0,
    )
    if public_prefixes["first_assistant_prefixes_over_context"]:
        failures.append("a public user prompt plus assistant marker exceeds ctx=64")
    if public_max_answer > 96:
        failures.append(f"a public assistant answer exceeds 96 characters: {public_max_answer}")

    forbidden_phrases = [
        "日常の小さな場面に当てはめると",
        "初心者向けで、難しい言葉は少なめ",
        "の順で試してください",
        "今の今日の目標",
        "最後に「最後に",
    ]
    for phrase in forbidden_phrases:
        if phrase in original:
            failures.append(f"known bad phrase remains in original: {phrase}")

    operation = {
        "たす": lambda left, right: left + right,
        "ひく": lambda left, right: left - right,
        "かける": lambda left, right: left * right,
    }
    arithmetic_checked = 0
    arithmetic_errors: list[str] = []
    for left, op, right, result in re.findall(
        r"(\d+)(たす|ひく|かける)(\d+)は(?:。 \[助手\])?(\d+)", original
    ):
        arithmetic_checked += 1
        expected = operation[op](int(left), int(right))
        if expected != int(result):
            arithmetic_errors.append(f"{left}{op}{right}={result}, expected {expected}")
    for value, divisor, result in re.findall(
        r"(\d+)を(\d+)で割ると。 \[助手\](\d+)です", original
    ):
        arithmetic_checked += 1
        if int(value) // int(divisor) != int(result) or int(value) % int(divisor):
            arithmetic_errors.append(f"{value}/{divisor}={result}")
    if arithmetic_errors:
        failures.extend(f"arithmetic mismatch: {item}" for item in arithmetic_errors)

    evaluation_cases = [block for block in evaluation.strip().split("\n\n") if block]
    if len(evaluation_cases) != 30:
        failures.append(f"expected 30 evaluation cases, found {len(evaluation_cases)}")
    if any(not case.endswith("[助手]") for case in evaluation_cases):
        failures.append("an evaluation case does not end with [助手]")
    evaluation_last_prefixes = []
    for case in evaluation_cases:
        last_user = case.rsplit("[利用者]", 1)[-1]
        last_user = last_user.split(" [助手]", 1)[0]
        evaluation_last_prefixes.append(len(f"[利用者]{last_user} [助手]"))
    if any(length > 64 for length in evaluation_last_prefixes):
        failures.append("an evaluation user prompt plus assistant marker exceeds ctx=64")
    train_user_turns = {
        text for turns in original_dialogues for role, text in turns if role == "利用者"
    }
    evaluation_user_turns = {
        match
        for case in evaluation_cases
        for match in re.findall(r"\[利用者\](.*?)(?= \[(?:利用者|助手)\]|$)", case)
    }
    leaked = sorted(train_user_turns & evaluation_user_turns)
    if leaked:
        failures.append(f"exact evaluation leakage: {leaked}")
    missing_codepoints = sorted(set(evaluation) - set(original))
    if missing_codepoints:
        failures.append("evaluation has out-of-vocabulary characters: " + "".join(missing_codepoints))

    manifest_rows = [
        json.loads(line) for line in manifest_path.read_text(encoding="utf-8").splitlines() if line
    ]
    if len(manifest_rows) != len(public_dialogues):
        failures.append("public manifest row count does not match public dialogues")
    if len({row["pair_sha256"] for row in manifest_rows}) != len(manifest_rows):
        failures.append("duplicate pair_sha256 values in public manifest")

    file_paths = [
        original_path,
        public_path,
        combined_path,
        evaluation_path,
        manifest_path,
        root / "corpus_stats.json",
        root / "build_corpus.py",
        Path(__file__).resolve(),
    ]
    result = {
        "status": "pass" if not failures else "fail",
        "failures": failures,
        "checks": {
            "original_unicode_characters": len(original),
            "public_unicode_characters": len(public),
            "combined_unicode_characters": len(combined),
            "original_dialogues": len(original_dialogues),
            "public_dialogues": len(public_dialogues),
            "combined_dialogues": len(combined_dialogues),
            "evaluation_cases": len(evaluation_cases),
            "evaluation_exact_leakage": len(leaked),
            "evaluation_oov_codepoints": len(missing_codepoints),
            "max_evaluation_user_prefix": max(evaluation_last_prefixes, default=0),
            "arithmetic_equations_checked": arithmetic_checked,
            "arithmetic_errors": len(arithmetic_errors),
            "public_max_assistant_turn": public_max_answer,
            "public_first_assistant_prefixes_over_context": public_prefixes[
                "first_assistant_prefixes_over_context"
            ],
            **prefixes,
        },
        "sha256": {path.name: sha256(path) for path in file_paths},
    }
    report_path.write_text(
        json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8", newline="\n"
    )
    print(json.dumps(result, ensure_ascii=False, indent=2))
    if failures:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
